/* 
 * Authors:
 * 	Matthew Swanson 30121485
 * 	Uijin Park 30056434
 * 
 * modified from tutorial code by Hamza Afzaal
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/mman.h>
#include "initGPIO.h"

unsigned int *getGPIOPtr(uint32_t baseAddr, char* filename)
{
	int fdgpio = open(filename, O_RDWR | O_SYNC); //mem
	
	if (fdgpio <0) {
		printf("unable to open\n");
		exit(1);
	}
	
	unsigned int *gpioPtr = (unsigned int *)mmap(
									0,
									4096,
									PROT_READ+PROT_WRITE,
									MAP_SHARED,
									fdgpio,
									baseAddr);
	
	return gpioPtr;
}


void unmapMem(uint32_t* baseAddr)
{
	munmap(baseAddr, 4096);
}
