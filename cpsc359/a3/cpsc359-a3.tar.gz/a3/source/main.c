/* 
 * Authors:
 * 	Matthew Swanson 30121485
 * 	Uijin Park 30056434
 * 
 * modified from tutorial code by Hamza Afzaal
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include <curses.h>
#include "framebuffer.h"
#include <stdint.h>
#include "initGPIO.h"
#include "utils.h"

#define GPFSEL0 0x00/4
#define GPFSEL1 0x04/4
#define GPFSEL2 0x08/4

#define GPSET0 0x1c/4
#define GPCLR0 0x28/4
#define GPLEV0 0x34/4

#define GPIO_PUP_PDN_CNTRL_REG1 0xe8/4

// PIN declarations
#define SDA 2
#define SCL 3

// base addresses
#define GPIO_BASE 0xFE200000
#define BSC1_BASE 0xFE804000

// MPU6050 slave address
#define MPU6050 0x68 // can be 0x69 depending upon the hardware

#define XRES 1280
#define YRES 720
#define BOXSIZE 64

// global variable declaration
uint32_t *gpioPtr;
uint32_t *bsc1Ptr;

// function template declaration
void Write_BSC(unsigned char reg_offset, unsigned char value);
unsigned char Read_BSC(unsigned char reg_offset);

/* Definitions */
typedef struct {
	int color;
	int x, y;
} Pixel;

typedef struct {
	int xoff;
	int yoff;
	int x, y; // dimesions
	int moveSpeed;
	int color;
} Box;

typedef struct {
	int up;
	int down;
	int left;
	int right;
	int x; // <- close button
} Controls;

// initialize the box and do the rest of the work here ... 

struct fbs framebufferstruct;
void drawPixel(Pixel *pixel);
void clearScreen(Pixel* pixel); // function to clear the pixels drawn to the screen
void drawBox(Box* box, Pixel* pixel); // function to draw shape on the screen

/* main function */
int main(){
	
	// get gpio pointer
    gpioPtr = getGPIOPtr(GPIO_BASE, "/dev/mem");  
    bsc1Ptr = getGPIOPtr(BSC1_BASE, "/dev/mem");
   
    Init_GPIO(gpioPtr, SDA, 4);
    Init_GPIO(gpioPtr, SCL, 4);
    
    // grab device id over i2c bus
    unsigned char deviceID = Read_BSC((unsigned char)0x75);

    // set configuration
    Write_BSC((unsigned char)0x6B, (unsigned char)0x01);
    Write_BSC((unsigned char)0x1A, (unsigned char)0x00);
    Write_BSC((unsigned char)0x1B, (unsigned char)0x18);
    Write_BSC((unsigned char)0x19, (unsigned char)0x07);
    Write_BSC((unsigned char)0x38, (unsigned char)0x01);

	/* initialize + get FBS */
	framebufferstruct = initFbInfo();
	
	/* initialize a pixel */
	Pixel *pixel;
	pixel = malloc(sizeof(Pixel));
	
	Controls* controls;
	controls = malloc(sizeof(Controls));
	
	Box* box;
	box = malloc(sizeof(Box));
	
	// initialize the dimentions and offsets for the box here 
	box->xoff = 0;
	box->yoff = 0;
	box->x = BOXSIZE;
	box->y = BOXSIZE;
	box->moveSpeed = BOXSIZE;
	box->color = 0xFCFCFC;
	
	////
	
    initscr();
    clearScreen(pixel);
    drawBox(box, pixel);
	for (;;)
    {
		drawBox(box, pixel);
		
		if (box->yoff >= 640 && box->xoff >= 1216) break;
		
		delay(100);
		
		handleInput(controls);
		
		// add logic to handle the controls to move the box around 
		// clear the screen only when a key is pressed
		if (controls->up) {
			if (box->yoff - box->moveSpeed < 0) continue;
			box->yoff -= box->moveSpeed;
			clearScreen(pixel);
		} else if (controls->left) {
			if (box->xoff - box->moveSpeed < 0) continue;
			box->xoff -= box->moveSpeed;
			clearScreen(pixel);
		} else if (controls->down) {
			if (box->yoff + box->moveSpeed > YRES - box->y) continue;
			box->yoff += box->moveSpeed;
			clearScreen(pixel);
		} else if (controls->right) {
			if (box->xoff + box->moveSpeed > XRES - box->x) continue;
			box->xoff += box->moveSpeed;
			clearScreen(pixel);
		} else if (controls->x) {
			break;
		}
    }

    endwin();
	
	
	/* free pixel's allocated memory */
	free(pixel);
	free(controls);
	free(box);
	controls = box = pixel = NULL;
	munmap(framebufferstruct.fptr, framebufferstruct.screenSize);
	
	// unmap character files
    unmapMem(gpioPtr);
    unmapMem(bsc1Ptr);
	
	return 0;
}

void handleInput(Controls* controls)
{
	controls->x = controls->up = controls->down = controls->left = controls->right = 0;

	unsigned char xhi = Read_BSC((unsigned char)0x43);
	unsigned char xlo = Read_BSC((unsigned char)0x44);
	unsigned char yhi = Read_BSC((unsigned char)0x45);
	unsigned char ylo = Read_BSC((unsigned char)0x46);
	
	short x = (xhi << 8) | xlo;
	short y = (yhi << 8) | ylo;
	
	short xbase = x;
	short ybase = y;

	while(1) {
		xhi = Read_BSC((unsigned char)0x43);
		xlo = Read_BSC((unsigned char)0x44);
		yhi = Read_BSC((unsigned char)0x45);
		ylo = Read_BSC((unsigned char)0x46);
	
		x = (xhi << 8) | xlo;
		y = (yhi << 8) | ylo;
	
		//printf("\nx: %d  \t| \t0x%x\ny: %d  \t| \t0x%x\n", x, x, y, y);
		
		int n = 5000;
		if (x > xbase+n) {
			controls->right = 1;
		} else if (x < xbase-n) {
			controls->left = 1;
		} else if (y > ybase+n) {
			controls->up = 1;
		} else if (y < ybase-n) {
			controls->down = 1;
		} else {
			continue;
		}
		return;
	}
	
}

void killBox(Box* box, Pixel* pixel) {
	
}

void drawBox(Box* box, Pixel* pixel)
{
	// add logic to draw box with appropriate offset value here
	for (int y = box->yoff; y < (box->yoff + box->y); y++)
	{
		for (int x = box->xoff; x < (box->xoff + box->x); x++)
		{
			pixel->color = box->color;
			pixel->x = x;
			pixel->y = y;

			drawPixel(pixel);
		}
	}
}

void clearScreen(Pixel *pixel)
{
	int colour = 0;	
	for (int y = 0; y < YRES; y++)
	{
		for (int x = 0; x < XRES; x++)
		{
			colour = 0b1110011110011100;	// a light grey
			if ((x % (2*BOXSIZE) > BOXSIZE-1) - (y % (2*BOXSIZE) > BOXSIZE-1)) colour = 0xFFFF;	// pure white obvs
			pixel->color = colour;
			pixel->x = x;
			pixel->y = y;

			drawPixel(pixel);
		}
	}
}


/* Draw a pixel */
void drawPixel(Pixel *pixel){
	long int location = (pixel->x + framebufferstruct.xOff) * (framebufferstruct.bpp / 8) +
                        (pixel->y + framebufferstruct.yOff) * framebufferstruct.lineLength;
	*((unsigned short int*)(framebufferstruct.fptr + location)) = pixel->color;
}

void Write_BSC(unsigned char reg_offset, unsigned char value) 
{
    // we append the data bits to the FIFO
    // to transfer it to the I2C bus
    // lets set it up ...     
    
	bsc1Ptr[3] = MPU6050;
	bsc1Ptr[2] = 2;
	bsc1Ptr[4] = (unsigned char)reg_offset;
	bsc1Ptr[4] = (unsigned char)value;
	bsc1Ptr[1] = (1 << 9) | (1 << 8) | (1 << 1);
	bsc1Ptr[0] = (1 << 15) | (1 << 7);

	BSC1_wait_done(bsc1Ptr);
    
}

unsigned char Read_BSC(unsigned char reg_offset)
{

	bsc1Ptr[3] = MPU6050;
	bsc1Ptr[2] = 1;
	bsc1Ptr[4] = (unsigned char)reg_offset;
	bsc1Ptr[1] = (1 << 9) | (1 << 8) | (1 << 1);
	bsc1Ptr[0] = (1 << 15) | (1 << 7);

	BSC1_wait_done(bsc1Ptr);

	bsc1Ptr[3] = MPU6050;
	bsc1Ptr[2] = 1;
	bsc1Ptr[1] = (1 << 9) | (1 << 8) | (1 << 1);
	bsc1Ptr[0] = (1 << 15) | (1 << 7) | (1 << 4) | 1;

	BSC1_wait_done(bsc1Ptr);

	unsigned char value = bsc1Ptr[4];

    return value;
}
