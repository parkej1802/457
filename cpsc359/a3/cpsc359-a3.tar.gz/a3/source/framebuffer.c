/* 
 * Authors:
 * 	Matthew Swanson 30121485
 * 	Uijin Park 30056434
 * 
 * modified from tutorial code by Hamza Afzaal
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include "framebuffer.h"

struct fbs initFbInfo(void)
{
    int fbfd = 0;
    struct fb_var_screeninfo vinfo;
    struct fb_fix_screeninfo finfo;
    long int screensize = 0;
    void *fbp = 0;

    // Open the file for reading and writing
    fbfd = open("/dev/fb0", O_RDWR);
    if (fbfd == -1) {
        perror("Error: cannot open framebuffer device");
        exit(1);
    }
    printf("The framebuffer device was opened successfully.\n");

    // Get fixed screen information
    // to get fixed information for the framebuffer such as start and 
    // length of the framebuffer memory
    if (ioctl(fbfd, FBIOGET_FSCREENINFO, &finfo) == -1) {
        perror("Error reading fixed information\n");
        exit(2);
    }

    // Get variable screen information
    // variable information about screen like screen resolution, margins,
    // and color properties
    if (ioctl(fbfd, FBIOGET_VSCREENINFO, &vinfo) == -1) {
        perror("Error reading variable information\n");
        exit(3);
    }

   
    


    // Figure out the size of the screen in bytes
    // this is double the size of screen as the screen is 16bpp 
    screensize = vinfo.xres_virtual * vinfo.yres_virtual * vinfo.bits_per_pixel / 8;

    // Map the device to memory
    fbp = (char *)mmap(0, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, fbfd, 0);
    
    if ((int)fbp == -1) {
        perror("Error: failed to map framebuffer device to memory");
        exit(4);
    }
    
    printf("The framebuffer device was mapped to memory successfully.\n");
    printf("%dx%d, %dbpp\n", vinfo.xres_virtual, vinfo.yres_virtual, vinfo.bits_per_pixel);
    printf("Screensize: %ld, Line length: %d, Pixel Offset: %d - %d\n", 
    screensize, finfo.line_length, vinfo.xoffset, vinfo.yoffset);
    
    struct fbs result = {(char *)fbp, (int) vinfo.xoffset, (int) vinfo.yoffset,
        (int) vinfo.bits_per_pixel, (int) finfo.line_length,
        (float) screensize, (int)vinfo.xres_virtual, (int)vinfo.yres_virtual};
    
    return result;

}
