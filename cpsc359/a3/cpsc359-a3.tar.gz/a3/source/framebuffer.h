/* 
 * Authors:
 * 	Matthew Swanson 30121485
 * 	Uijin Park 30056434
 * 
 * modified from tutorial code by Hamza Afzaal
 */

#ifndef FRAMEBUFF
#define FRAMEBUFF

/* definitions */
struct fbs {
	char *fptr;					// framebuffer pointer
	int xOff; 					// x offset
	int yOff;					// x offset
	int bpp;					// bits per pixel
	int lineLength;				// Line Length
	float screenSize;			// Screen Size
	int xRes;					// X Resolution Size
	int yRes;					// Y Resolution Size
};
	
struct fbs initFbInfo(void);


#endif
