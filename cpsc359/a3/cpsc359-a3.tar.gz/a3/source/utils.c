/* 
 * Authors:
 * 	Matthew Swanson 30121485
 * 	Uijin Park 30056434
 * 
 * modified from tutorial code by Hamza Afzaal
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <stdint.h>

void delay(unsigned int howLong)
{
    struct timespec sleeper, dummy;
    
    sleeper.tv_sec = (time_t)(howLong / 1000);
    sleeper.tv_nsec = (long)(howLong % 1000) * 1000000;
    
    nanosleep(&sleeper, &dummy);
}

void Init_GPIO(uint32_t* basePtr, int pin, int fn)
{
    volatile uint32_t* pin_offset = basePtr + (pin/10);
    
    int value = fn << ((pin % 10) * 3);
    int mask = 0b111 << ((pin % 10) * 3);
    *pin_offset = (*pin_offset & ~mask) | (value & mask);
}

void BSC1_wait_done(uint32_t* basePtr)
{
    while(!(basePtr[1] & 0x02)) // check the done bit to be 1, as in 0b10
    {
        delay(1);
    }
}
