/* 
 * Authors:
 * 	Matthew Swanson 30121485
 * 	Uijin Park 30056434
 * 
 * modified from tutorial code by Hamza Afzaal
 */

#ifndef initGPIO
#define initGPIO

unsigned int *getGPIOPtr(uint32_t baseAddr, char* filename);

void unmapMem(uint32_t* baseAddr);


#endif
