/* 
 * Authors:
 * 	Matthew Swanson 30121485
 * 	Uijin Park 30056434
 * 
 * modified from tutorial code by Hamza Afzaal
 */

#ifndef utils
#define utils

void delay(unsigned int howLong);

void Init_GPIO(uint32_t* basePtr, int pin, int fn);
void BSC1_wait_done(uint32_t* basePtr);


#endif
