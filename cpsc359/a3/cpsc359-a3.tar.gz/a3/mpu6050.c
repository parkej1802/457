

#define BLOCK_SIZE	4096

void mapRegisters() {

	int GPIO_BASE = bcm_host_get_peripheral_address();

	// Define gpio0/1 as sda0/scl0 (alt 0)
	gpio[0] = gpio[0] & ~(0b111 << (SDA1 * 3));	// clear gpio2
	gpio[0] = gpio[0] | ~(0b100 << (SDA1 * 3));	// alt function 0 in gpio2
	gpio[0] = gpio[0] & ~(0b111 << (SCL1 * 3));	// clear gpio3
	gpio[0] = gpio[0] | ~(0b100 << (SCL1 * 3));	// alt function 0 in gpio3

	//Open /dev/mem
	int fd = open("/dev/mem", O_RDWR | O_SYNC);

	unsigned int *bscl = (unsigned int *) mmap(
			NULL,
			BLOCK_SIZE,
			PROT_READ | PROT_WRITE,
			MAP_SHARED,
			fd,
			BSC1_BASE);
