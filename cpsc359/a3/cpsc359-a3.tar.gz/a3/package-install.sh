#!/bin/bash 

sudo apt-get install libncurses5-dev libncursesw5-dev
