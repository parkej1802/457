#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "initGPIO.h"

unsigned int *getGPIOPtr(void)
{
	int fdgpio = open("/dev/gpiomem", O_RDWR | O_SYNC); //mem
	
	if (fdgpio <0) {
		printf("unable to open");
		exit(1);
	}
	
	unsigned int *gpioPtr = (unsigned int *)mmap(
									0,
									4096,
									PROT_READ+PROT_WRITE,
									MAP_SHARED,
									fdgpio,
									0x200000); // 0xfe200000 // or use 0x200000 for gpiomem
	
	return gpioPtr;
}
