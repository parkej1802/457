#include <unistd.h>
#include <stdio.h>
#include <stdint.h>
#include "initGPIO.h"
#include <wiringPi.h>
#include <stdlib.h>


#define GPFSEL1 0x04/4
#define GPFSEL2 0x08/4


#define GPSET0 0x1c/4 
#define GPCLR0 0x28/4
#define GPLEV0 0x34/4

#define GPIO_PUP_PDN_CNTRL_REG1 0xe8/4

#define INP_GPIO(p) *(gpioPtr+((p)/10)) &= ~(7<<(((p)%10)*3)); //Setting the function of any pin p to input
#define OUT_GPIO(p) *(gpioPtr+((p)/10)) |= (1<<(((p)%10)*3)); //Setting the function of any pin p to output
#define SET_GPIO_ALT(g,a) *(gpioPtr+(((g)/10)) |= (((a) <=3?(a)+4:(a)==4?3:2)<<(((g)%10)*3))

#define CLK 11 
#define LAT 9
#define DAT 10


void init_GPIO(unsigned int *gpioPtr) {
    INP_GPIO(CLK);  //CLK
    OUT_GPIO(CLK);  
    INP_GPIO(LAT);  //LATCH
    OUT_GPIO(LAT);
    INP_GPIO(DAT);  //DATA
}

//Writing to Latch pins 0-31
void Write_Latch(unsigned int *gpioPtr, int a) {
    if (a == 1) {
        gpioPtr[GPSET0] = 1<<LAT;
    }
    else {
        gpioPtr[GPCLR0] = 1<<LAT;
    }
}

//Writing to Clock pin 0-31
void Write_Clock(unsigned int *gpioPtr, int a) {
    if (a == 1) {
        gpioPtr[GPSET0] = 1<<CLK;
    }
    else {
        gpioPtr[GPCLR0] = 1<<CLK;
    }
}

//read data and get pin value
unsigned int Read_Data(unsigned int *gpioPtr) {
    return (gpioPtr[GPLEV0] >> DAT) & 1;
}

//wait microseconds
void Wait(unsigned int howlong) {
    usleep(howlong);
}

//Priting which button has been pressed  
void Print_Message(int button) {
    if (button == 1) {
        printf("You have pressed B\n\nPlease press a button...\n\n");
    }
    else if (button == 2) {
        printf("You have pressed Y\n\nPlease press a button...\n\n");
    }
    else if (button == 3) {
        printf("You have pressed Select\n\nPlease press a button...\n\n");
    }
    else if (button == 4) {
        printf("You have pressed Start\n\nPlease press a button...\n\n");
    }
    else if (button == 5) {
        printf("You have pressed Joy-pad UP\n\nPlease press a button...\n\n");
    }
    else if (button == 6) {
        printf("You have pressed Joy-pad DOWN\n\nPlease press a button...\n\n");
    }
    else if (button == 7) {
        printf("You have pressed Joy-pad LEFT\n\nPlease press a button...\n\n");
    }
    else if (button == 8) {
        printf("You have pressed Joy-pad RIGHT\n\nPlease press a button...\n\n");
    }
    else if (button == 9) {
        printf("You have pressed A\n\nPlease press a button...\n\n");
    }
    else if (button == 10) {
        printf("You have pressed X\n\n Terminating Program ");
        exit(0);//Terminating program when x is pressed
    }
    else if (button == 11) {
        printf("You have pressed Left\n\nPlease press a button...\n\n");
    }
    else if (button == 12) {
        printf("You have pressed Right\n\nPlease press a button...\n\n");
    }
}



int buttons[16];

//It reads our input
void Read_SNES(unsigned int *gpioPtr) {
    for(int i=0; i<16; i++) { //reset to buttons to 1 
        buttons[i] = 1;
    }
    
    Write_Clock(gpioPtr, 1); //set clock
    Write_Latch(gpioPtr, 1); //set latch
    Wait(12); //delay 12 microseconds
    Write_Latch(gpioPtr, 0); //set latch
    
    int i = 0;
    int pin;
    
    while (i < 16) {
        Wait(6);
        Write_Clock(gpioPtr, 0); //clear clock
        pin = Read_Data(gpioPtr); // get the pin value
        Wait(6);
        if (pin == 0 && i <= 11) { //from button to 0 to 11, total 12 buttons
            buttons[i] = 0; //set that button to 0;
        }
        Write_Clock(gpioPtr, 1); //set clock
        i++;
    }
}



int main() {

    unsigned int *gpioPtr = getGPIOPtr();
    init_GPIO(gpioPtr); 
   
    printf("Created by: Uijin Park\n\nPlease press a button...\n\n");

    while (1) {
        Read_SNES(gpioPtr);//read input
    
        for (int i = 0; i < 16; i++) {
            if (buttons[i] == 0) { //if button is pressed then it will be 0
                Print_Message(i + 1); // printing i + 1 since array starts at 0
                sleep(2);
                break; //break the for loop and get back to while loop
            }
        }
    }
    return 0;
}
