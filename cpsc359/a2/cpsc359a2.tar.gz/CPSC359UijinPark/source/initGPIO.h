#ifndef initGPIO
#define initGPIO

unsigned int *getGPIOPtr(void);


#endif
