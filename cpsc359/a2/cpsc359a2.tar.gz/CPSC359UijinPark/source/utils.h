#ifndef utils
#define utils

void delay(unsigned int howLong);


#endif
