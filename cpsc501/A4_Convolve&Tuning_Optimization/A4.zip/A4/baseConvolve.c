/**

Unfinished code for a convolution of two input .wav files. The first file being a sample tone and the second being an impulse tone.
A few functions for reading data and writing data have been left out for students to try

*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <stdint.h>

#include <time.h>

/*  CONSTANTS  ***************************************************************/
#define PI                3.14159265358979

/*  Test tone frequency in Hz  */
#define FREQUENCY         440.0

/*  Test tone duration in seconds  */
#define DURATION          2.0				

/*  Standard sample rate in Hz  */
#define SAMPLE_RATE       44100.0

/*  Standard sample size in bits  */
#define BITS_PER_SAMPLE   16

/*  Standard sample size in bytes  */		
#define BYTES_PER_SAMPLE  (BITS_PER_SAMPLE/8)

/*  Number of channels  */
#define MONOPHONIC        1
#define STEREOPHONIC      2


size_t data_input_size;
size_t data_IR_size;

short *audio_input_data;
short *audio_IR_data; 

// Function definitions (:

float shortToFloat(short value);
float bytesToFloat(char firstByte, char secondByte) ;
void convolve(float x[], int N, float h[], int M, float y[], int P);
void readTone(char *inputTone, char* IRTone);
void printValue(char *tone);
void writeWaveFileHeader(int channels, int numberSamples, double outputRate, FILE *outputFile);
size_t fwriteIntLSB(int data, FILE *stream);
size_t fwriteShortLSB(short int data, FILE *stream);
void writeOutputFile(char *fileName, int channels, int numberSamples, double outputRate, int16_t* array);
// struct to hold all data up until the end of subchunk1
// you still have 8 bytes to read before actual data, namely being subchunk2ID & subChunk2Size
// note it may actually be more than 8 bytes as subchunk1size may not be 16!
typedef struct {
    char chunk_id[4];
    int chunk_size;
    char format[4];
    char subchunk1_id[4];
    int subchunk1_size;
    short audio_format;
    short num_channels;
    int sample_rate;
    int byte_rate;
    short block_align;
    short bits_per_sample;
} WavHeader;

int16_t floatToInt(float value) {
    int16_t result;
    result = value * 32767;
    return result;
}

float shortToFloat(short value) {
    return value / 32768.0f;
}


// main line of execution
int main (int argc, char *argv[]){

    clock_t begin = clock();

    char *inputTone = NULL;
    char *IRTone = NULL;
    char *outputTone = NULL;

    /*  Process the command line arguments  */
    if (argc == 4) {
        /*  Set a pointer to the output filename  */
        inputTone = argv[1]; IRTone = argv[2]; outputTone = argv[3];

    }
    else {
        /*  The user did not supply the correct number of command-line
            arguments.  Print out a usage message and abort the program.  */
        fprintf(stderr, "Usage:  %s sampleTone impulseTone\n", argv[0]); exit(-1);
    }
    // printValue(inputTone);
    // printValue(IRTone);
    readTone(inputTone, IRTone);

    int N = data_input_size / sizeof(short);
    int M = data_IR_size / sizeof(short);
    int P = N + M - 1;
 
    float *x = malloc(N * sizeof(float));
    float *h = malloc(M * sizeof(float));
    float *y = malloc(P * sizeof(float));

    for (int i = 0; i < N; i++) {
      x[i] = shortToFloat(audio_input_data[i]);
    }

    for (int i = 0; i < M; i++) {
      h[i] = shortToFloat(audio_IR_data[i]);
    }


    convolve(x, N, h, M, y, P);

    float min = y[0];
    float max = y[0];

    for (int i = 0; i < P; i++) {
        if (y[i] < min) {
            min = y[i];
        }
        if (y[i] > max) {
            max = y[i];
        }
    }


    for (int i = 0; i < P; i++) {
        y[i] = ((y[i] - min) / (max - min)) * 2.0f - 1.0f;
    }
    

    int16_t* array = malloc(sizeof(int16_t)*P);

    for(int i = 0; i < P; i++){
        array[i]=floatToInt(y[i]);
    }
    

    writeOutputFile(outputTone, 1, P, SAMPLE_RATE, array);
    clock_t end = clock();
    double elapsed_time = (double)(end - begin) / CLOCKS_PER_SEC;

    printf("Elapsed time: %.2f seconds\n", elapsed_time);
    
    free(x);
    free(h);
    free(y);
    free(array);
}

void printValue(char *tone) {
    FILE *outputFileStream = fopen(tone, "rb");

    WavHeader wavHeader;

    fread(&wavHeader, sizeof(wavHeader), 1, outputFileStream);

    printf("Chunk ID: %.4s\n", wavHeader.chunk_id);
    printf("Chunk Size: %d\n", wavHeader.chunk_size);
    printf("Format: %.4s\n", wavHeader.format);
    printf("Subchunk1 ID: %.4s\n", wavHeader.subchunk1_id);
    printf("Subchunk1 Size: %d\n", wavHeader.subchunk1_size);
    printf("Audio Format: %d\n", wavHeader.audio_format);
    printf("Number of Channels: %d\n", wavHeader.num_channels);
    printf("Sample Rate: %d\n", wavHeader.sample_rate);
    printf("Byte Rate: %d\n", wavHeader.byte_rate);
    printf("Block Align: %d\n", wavHeader.block_align);
    printf("Bits Per Sample: %d\n", wavHeader.bits_per_sample);
}

/**
Read the tones, and call convolve on them
*/

void readTone(char *InputTone, char *IRTone){
    FILE *inputfileStream = fopen(InputTone, "rb");
    FILE *IRfileStream = fopen(IRTone, "rb");

    WavHeader header_input;
    WavHeader header_IR;

    // read the header subchunk 1, write the header into a new file
    fread(&header_input, sizeof(header_input), 1, inputfileStream);
    fread(&header_IR, sizeof(header_IR), 1, IRfileStream);


    if (header_input.subchunk1_size != 16){
        // eliminate Null Bytes
        int remainder = header_input.subchunk1_size -16;
        char randomVar[remainder];
        fread(randomVar, remainder, 1, inputfileStream);
    }

    if (header_IR.subchunk1_size != 16){
        // eliminate Null Bytes
        int remainder = header_IR.subchunk1_size -16;
        char randomVar[remainder];
        fread(randomVar, remainder, 1, IRfileStream);
    }

    char subchunk2_input_id[4];
    char subchunk2_IR_id[4];

    int subchunk2_input_size; // an integer is 4 bytes
    int subchunk2_IR_size;

    fread(&subchunk2_input_id, sizeof(subchunk2_input_id), 1, inputfileStream);
    fread(&subchunk2_input_size, sizeof(subchunk2_input_size), 1, inputfileStream);

    fread(&subchunk2_IR_id, sizeof(subchunk2_IR_id), 1, IRfileStream);
    fread(&subchunk2_IR_size, sizeof(subchunk2_IR_size), 1, IRfileStream);
   

    int num_input = subchunk2_input_size / (header_input.bits_per_sample / 8); // number of data points in the sample
    int num_IR = subchunk2_IR_size / (header_IR.bits_per_sample / 8);
    /*
            Now Please Try the following:
            1. Read the two files, extract from each of them a float array, and a size. 
                You may find it helpful to use the other code provided in this tutorial for file reading.
            2. Call Convolve on the outputs
            3. Write the output.wav, making sure to write the header information as well.
    */

    data_input_size = subchunk2_input_size;
    data_IR_size = subchunk2_IR_size;
    audio_input_data = (short *)malloc(data_input_size);
    audio_IR_data = (short *)malloc(data_IR_size);


    fread(audio_input_data, sizeof(short), data_input_size, inputfileStream);
    fread(audio_IR_data, sizeof(short), data_IR_size, IRfileStream);

    fclose(inputfileStream);
    fclose(IRfileStream);

}

// Function to convert two bytes to one float in the range -1 to 1
// This is used as .wav files store data in short format (typically 16 bits, can also be extracted from the bits_per_sample header)
// assumes the data is read in bytes

float bytesToFloat(char firstByte, char secondByte) {
    // Convert two bytes to one short (little endian)
    short s = (secondByte << 8) | firstByte;
    // Convert to range from -1 to (just below) 1
    return s / 32768.0;
}

void convolve(float x[], int N, float h[], int M, float y[], int P)
{
    int n,m;

    /* Clear Output Buffer y[] */
    for (n=0; n < P; n++)
    {
        y[n] = 0.0;
    }

    /* Outer Loop: process each input value x[n] in turn */
    for (n=0; n<N; n++){
        /* Inner loop: process x[n] with each sample of h[n] */
        for (m=0; m<M; m++){
            y[n+m] += x[n] * h[m];
        }
    }
}

void writeWaveFileHeader(int channels, int numberSamples,
                         double outputRate, FILE *outputFile)
{
    /*  Calculate the total number of bytes for the data chunk  */
    int dataChunkSize = channels * numberSamples * BYTES_PER_SAMPLE;
	
    /*  Calculate the total number of bytes for the form size  */
    int formSize = 36 + dataChunkSize;
	
    /*  Calculate the total number of bytes per frame  */
    short int frameSize = channels * BYTES_PER_SAMPLE;
	
    /*  Calculate the byte rate  */
    int bytesPerSecond = (int)ceil(outputRate * frameSize);

    /*  Write header to file  */
    /*  Form container identifier  */
    fputs("RIFF", outputFile);
      
    /*  Form size  */
    fwriteIntLSB(formSize, outputFile);
      
    /*  Form container type  */
    fputs("WAVE", outputFile);

    /*  Format chunk identifier (Note: space after 't' needed)  */
    fputs("fmt ", outputFile);
      
    /*  Format chunk size (fixed at 16 bytes)  */
    fwriteIntLSB(16, outputFile);

    /*  Compression code:  1 = PCM  */
    fwriteShortLSB(1, outputFile);

    /*  Number of channels  */
    fwriteShortLSB((short)channels, outputFile);

    /*  Output Sample Rate  */
    fwriteIntLSB((int)outputRate, outputFile);

    /*  Bytes per second  */
    fwriteIntLSB(bytesPerSecond, outputFile);

    /*  Block alignment (frame size)  */
    fwriteShortLSB(frameSize, outputFile);

    /*  Bits per sample  */
    fwriteShortLSB(BITS_PER_SAMPLE, outputFile);

    /*  Sound Data chunk identifier  */
    fputs("data", outputFile);

    /*  Chunk size  */
    fwriteIntLSB(dataChunkSize, outputFile);
}

size_t fwriteIntLSB(int data, FILE *stream)
{
    unsigned char array[4];

    array[3] = (unsigned char)((data >> 24) & 0xFF);
    array[2] = (unsigned char)((data >> 16) & 0xFF);
    array[1] = (unsigned char)((data >> 8) & 0xFF);
    array[0] = (unsigned char)(data & 0xFF);
    return fwrite(array, sizeof(unsigned char), 4, stream);
}

size_t fwriteShortLSB(short int data, FILE *stream)
{
    unsigned char array[2];

    array[1] = (unsigned char)((data >> 8) & 0xFF);
    array[0] = (unsigned char)(data & 0xFF);
    return fwrite(array, sizeof(unsigned char), 2, stream);
}

void writeOutputFile(char *fileName, int channels, int numberSamples, double outputRate, int16_t* array) {
    FILE *outputFileStream = fopen(fileName, "wb");
    // FILE* file = fopen("output.txt", "w");
    writeWaveFileHeader(channels, numberSamples, outputRate, outputFileStream);

    for(int i = 0; i < numberSamples; i++){
        fwriteShortLSB(array[i], outputFileStream);
        // fprintf(file, "%d\n", array[i]);
    }

    // fclose(file);

    fclose(outputFileStream);

}
