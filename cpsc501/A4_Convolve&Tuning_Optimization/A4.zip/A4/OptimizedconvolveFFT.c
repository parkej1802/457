/**

Unfinished code for a convolution of two input .wav files. The first file being a sample tone and the second being an impulse tone.
A few functions for reading data and writing data have been left out for students to try

*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdint.h>

/*  CONSTANTS  ***************************************************************/
#define PI                3.14159265358979

/*  Test tone frequency in Hz  */
#define FREQUENCY         440.0

/*  Test tone duration in seconds  */
#define DURATION          2.0				

/*  Standard sample rate in Hz  */
#define SAMPLE_RATE       44100.0

/*  Standard sample size in bits  */
#define BITS_PER_SAMPLE   16

/*  Standard sample size in bytes  */		
#define BYTES_PER_SAMPLE  (BITS_PER_SAMPLE/8)

/*  Number of channels  */
#define MONOPHONIC        1
#define STEREOPHONIC      2


size_t data_input_size;
size_t data_IR_size;

short *audio_input_data;
short *audio_IR_data; 

int ms_input, ms_IR, ms;

#define SWAP(a,b)  tempr=(a);(a)=(b);(b)=tempr
// Function to pad zeros to the input array to make its length M
void pad_zeros_to(double *arr, int current_length, int M) {
    int padding = M - current_length;
    for (int i = 0; i < padding; ++i) {
        arr[current_length + i] = 0.0;
    }
}

void four1(double data[], int nn, int isign)
{
    unsigned long n, mmax, m, j, istep, i;
    double wtemp, wr, wpr, wpi, wi, theta;
    double tempr, tempi;

    n = nn << 1;
    j = 1;

    for (i = 1; i < n; i += 2) {
	if (j > i) {
	    SWAP(data[j], data[i]);
	    SWAP(data[j+1], data[i+1]);
	}
	m = nn;
	while (m >= 2 && j > m) {
	    j -= m;
	    m >>= 1;
	}
	j += m;
    }

    mmax = 2;
    while (n > mmax) {
	istep = mmax << 1;
	theta = isign * (6.28318530717959 / mmax);
	wtemp = sin(0.5 * theta);
	wpr = -2.0 * wtemp * wtemp;
	wpi = sin(theta);
	wr = 1.0;
	wi = 0.0;
	for (m = 1; m < mmax; m += 2) {
	    for (i = m; i <= n; i += istep) {
		j = i + mmax;
		tempr = wr * data[j] - wi * data[j+1];
		tempi = wr * data[j+1] + wi * data[j];
		data[j] = data[i] - tempr;
		data[j+1] = data[i+1] - tempi;
		data[i] += tempr;
		data[i+1] += tempi;
	    }
	    wr = (wtemp = wr) * wpr - wi * wpi + wr;
	    wi = wi * wpr + wtemp * wpi + wi;
	}
	mmax = istep;
    }
    
}

// Function to reverse an array
void reverse_array(double *arr, int length) {
    int i, j;
    double temp;

    for (i = 0, j = length - 1; i < j; ++i, --j) {
        temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}

// Function to find the next power of 2 greater than or equal to n
int next_power_of_2(int n) {
    return pow(2, (int)(log2(n - 1) + 1));
}

void convolution(double *x, int K, double *h, double *y) {

    // Perform the DFT
    for (int k = 0, nn = 0; k < K; k++, nn += 2)
    {
	    y[nn] = ((x[nn] * h[nn]) - (x[nn+1] * h [nn+1]));
	    y[nn+1] = ((x[nn] * h[nn+1]) + (x[nn+1] * h[nn]));
	}
}

// Function definitions (:

float shortToFloat(short value);
float bytesToFloat(char firstByte, char secondByte) ;
void readTone(char *inputTone, char* IRTone);
void printValue(char *tone);
void writeWaveFileHeader(int channels, int numberSamples, double outputRate, FILE *outputFile);
size_t fwriteIntLSB(int data, FILE *stream);
size_t fwriteShortLSB(short int data, FILE *stream);
void writeOutputFile(char *fileName, int channels, int numberSamples, double outputRate, int16_t* array);
// struct to hold all data up until the end of subchunk1
// you still have 8 bytes to read before actual data, namely being subchunk2ID & subChunk2Size
// note it may actually be more than 8 bytes as subchunk1size may not be 16!
typedef struct {
    char chunk_id[4];
    int chunk_size;
    char format[4];
    char subchunk1_id[4];
    int subchunk1_size;
    short audio_format;
    short num_channels;
    int sample_rate;
    int byte_rate;
    short block_align;
    short bits_per_sample;
} WavHeader;


WavHeader header_input;
WavHeader header_IR;

int16_t floatToInt(float value) {
    int16_t result;
    result = value * 32767;
    return result;
}

float shortToFloat(short value) {
    return value / 32768.0f;
}

double shortToDouble(short value) {
    return value / 32768.0;
}

int16_t doubleToInt(double value) {
    int16_t result;
    result = value * 32767;
    return result;
}

// main line of execution
int main (int argc, char *argv[]){

    clock_t begin = clock();

    char *inputTone = NULL;
    char *IRTone = NULL;
    char *outputTone = NULL;

    /*  Process the command line arguments  */
    if (argc == 4) {
        /*  Set a pointer to the output filename  */
        inputTone = argv[1]; IRTone = argv[2]; outputTone = argv[3];

    }
    else {
        /*  The user did not supply the correct number of command-line
            arguments.  Print out a usage message and abort the program.  */
        fprintf(stderr, "Usage:  %s inputTone IRTOne\n", argv[0]); exit(-1);
    }

    // printf("----------------------\n");
    // printValue(inputTone);
    // printf("----------------------\n");
    // printValue(IRTone);
    // printf("----------------------\n");

    readTone(inputTone, IRTone);

    int N = data_input_size / sizeof(short);
    int M = data_IR_size / sizeof(short);
    int P = N + M - 1;

    // need to find N and M which one is larger 

    int max = 0;
    if (N > M) {
        max = N;
    }
    else {
        max = M;
    }
 
    int K = next_power_of_2(max + max);

    double *x = (double *)calloc(K+K, sizeof(double));
    double *h = (double *)calloc(K+K, sizeof(double));
    double *y = (double *)calloc(K+K, sizeof(double));


    for (int i = 0; i < N; i += 2) {
        x[i+i] = shortToDouble(audio_input_data[i]);
        x[i+i + 1] = 0.0;

        if (i + 1 < N) {
            x[(i+1)+(i + 1)] = shortToDouble(audio_input_data[i + 1]);
            x[(i+1)+(i + 1) + 1] = 0.0;
        }  
    }

    for (int i = 0; i < M; i += 2) {
        h[i + i] = shortToDouble(audio_IR_data[i]); 
        h[i+i + 1] = 0.0;

        if (i + 1 < M) {
            h[(i+1)+(i + 1)] = shortToDouble(audio_IR_data[i + 1]);
            h[(i+1)+(i + 1) + 1] = 0.0;
        }
    }

    pad_zeros_to(x, N+N, K+K);
    pad_zeros_to(h, M+M, K+K);

    four1(x-1, K, 1);
    four1(h-1, K, 1);

    convolution(x, K, h, y);

    four1(y-1, K, -1);

    for(int i = 0, k = 0; k < P; k++, i+= 2){
        y[i] /= (double)K;
        y[i+1] /= (double)K;
    }

    double miny = y[0];
    double maxy = y[0];

    for (int i = 0; i < K * 2; i++) {
        if (y[i] < miny) {
            miny = y[i];
        }
        if (y[i] > maxy) {
            maxy = y[i];
        }
    }

    double scale = 2.0 / (maxy - miny);

    for (int i = 0; i < K * 2; i++) {
        y[i] = (y[i] - miny) * scale - 1.0;
    }
        
    int16_t* array = malloc(sizeof(int16_t)*P);

    for(int i = 0; i < P; i++){
        array[i] = doubleToInt(y[i+i]);
    }
        
    writeOutputFile(outputTone, 1, P, SAMPLE_RATE, array);

    clock_t end = clock();
    double elapsed_time = (double)(end - begin) / CLOCKS_PER_SEC;

    printf("Elapsed time: %.2f seconds\n", elapsed_time);

    free(x);
    free(h);
    free(y);
    free(array);
    
}

void printValue(char *tone) {
    FILE *outputFileStream = fopen(tone, "rb");

    WavHeader wavHeader;

    fread(&wavHeader, sizeof(wavHeader), 1, outputFileStream);

    printf("Chunk ID: %.4s\n", wavHeader.chunk_id);
    printf("Chunk Size: %d\n", wavHeader.chunk_size);
    printf("Format: %.4s\n", wavHeader.format);
    printf("Subchunk1 ID: %.4s\n", wavHeader.subchunk1_id);
    printf("Subchunk1 Size: %d\n", wavHeader.subchunk1_size);
    printf("Audio Format: %d\n", wavHeader.audio_format);
    printf("Number of Channels: %d\n", wavHeader.num_channels);
    printf("Sample Rate: %d\n", wavHeader.sample_rate);
    printf("Byte Rate: %d\n", wavHeader.byte_rate);
    printf("Block Align: %d\n", wavHeader.block_align);
    printf("Bits Per Sample: %d\n", wavHeader.bits_per_sample);
}

/**
Read the tones, and call convolve on them
*/

void readTone(char *InputTone, char *IRTone){
    FILE *inputfileStream = fopen(InputTone, "rb");
    FILE *IRfileStream = fopen(IRTone, "rb");

    WavHeader header_input;
    WavHeader header_IR;

    // read the header subchunk 1, write the header into a new file
    fread(&header_input, sizeof(header_input), 1, inputfileStream);
    fread(&header_IR, sizeof(header_IR), 1, IRfileStream);


    if (header_input.subchunk1_size != 16){  
        // eliminate Null Bytes
        int remainder = header_input.subchunk1_size -16;
        char randomVar[remainder];
        fread(randomVar, remainder, 1, inputfileStream);
    }

    if (header_IR.subchunk1_size != 16){
        // eliminate Null Bytes
        int remainder = header_IR.subchunk1_size -16;
        char randomVar[remainder];
        fread(randomVar, remainder, 1, IRfileStream);
    }

    char subchunk2_input_id[4];
    char subchunk2_IR_id[4];

    int subchunk2_input_size; // an integer is 4 bytes
    int subchunk2_IR_size;

    fread(&subchunk2_input_id, sizeof(subchunk2_input_id), 1, inputfileStream);
    fread(&subchunk2_input_size, sizeof(subchunk2_input_size), 1, inputfileStream);

    fread(&subchunk2_IR_id, sizeof(subchunk2_IR_id), 1, IRfileStream);
    fread(&subchunk2_IR_size, sizeof(subchunk2_IR_size), 1, IRfileStream);
   

    int num_input = subchunk2_input_size / (header_input.bits_per_sample / 8); // number of data points in the sample
    int num_IR = subchunk2_IR_size / (header_IR.bits_per_sample / 8);

    data_input_size = subchunk2_input_size;
    data_IR_size = subchunk2_IR_size;
    audio_input_data = (short *)malloc(data_input_size);
    audio_IR_data = (short *)malloc(data_IR_size);


    fread(audio_input_data, sizeof(short), data_input_size, inputfileStream);
    fread(audio_IR_data, sizeof(short), data_IR_size, IRfileStream);

    fclose(inputfileStream);
    fclose(IRfileStream);

}

// Function to convert two bytes to one float in the range -1 to 1
// This is used as .wav files store data in short format (typically 16 bits, can also be extracted from the bits_per_sample header)
// assumes the data is read in bytes

float bytesToFloat(char firstByte, char secondByte) {
    // Convert two bytes to one short (little endian)
    short s = (secondByte << 8) | firstByte;
    // Convert to range from -1 to (just below) 1
    return s / 32768.0;
}


void writeWaveFileHeader(int channels, int numberSamples,
                         double outputRate, FILE *outputFile)
{
    /*  Calculate the total number of bytes for the data chunk  */
    int dataChunkSize = channels * numberSamples * BYTES_PER_SAMPLE;
	
    /*  Calculate the total number of bytes for the form size  */
    int formSize = 36 + dataChunkSize;
	
    /*  Calculate the total number of bytes per frame  */
    short int frameSize = channels * BYTES_PER_SAMPLE;
	
    /*  Calculate the byte rate  */
    int bytesPerSecond = (int)ceil(outputRate * frameSize);

    /*  Write header to file  */
    /*  Form container identifier  */
    fputs("RIFF", outputFile);
      
    /*  Form size  */
    fwriteIntLSB(formSize, outputFile);
      
    /*  Form container type  */
    fputs("WAVE", outputFile);

    /*  Format chunk identifier (Note: space after 't' needed)  */
    fputs("fmt ", outputFile);
      
    /*  Format chunk size (fixed at 16 bytes)  */
    fwriteIntLSB(16, outputFile);

    /*  Compression code:  1 = PCM  */
    fwriteShortLSB(1, outputFile);

    /*  Number of channels  */
    fwriteShortLSB((short)channels, outputFile);

    /*  Output Sample Rate  */
    fwriteIntLSB((int)outputRate, outputFile);

    /*  Bytes per second  */
    fwriteIntLSB(bytesPerSecond, outputFile);

    /*  Block alignment (frame size)  */
    fwriteShortLSB(frameSize, outputFile);

    /*  Bits per sample  */
    fwriteShortLSB(BITS_PER_SAMPLE, outputFile);

    /*  Sound Data chunk identifier  */
    fputs("data", outputFile);

    /*  Chunk size  */
    fwriteIntLSB(dataChunkSize, outputFile);
}

size_t fwriteIntLSB(int data, FILE *stream)
{
    unsigned char array[4];

    array[3] = (unsigned char)((data >> 24) & 0xFF);
    array[2] = (unsigned char)((data >> 16) & 0xFF);
    array[1] = (unsigned char)((data >> 8) & 0xFF);
    array[0] = (unsigned char)(data & 0xFF);
    return fwrite(array, sizeof(unsigned char), 4, stream);
}

size_t fwriteShortLSB(short int data, FILE *stream)
{
    unsigned char array[2];

    array[1] = (unsigned char)((data >> 8) & 0xFF);
    array[0] = (unsigned char)(data & 0xFF);
    return fwrite(array, sizeof(unsigned char), 2, stream);
}

void writeOutputFile(char *fileName, int channels, int numberSamples, double outputRate, int16_t* array) {
    FILE *outputFileStream = fopen(fileName, "wb");
    // FILE* file = fopen("optfftoutput.txt", "w");
    writeWaveFileHeader(channels, numberSamples, outputRate, outputFileStream);

    for(int i = 0; i < numberSamples; i++){
        fwriteShortLSB(array[i], outputFileStream);
        // fprintf(file, "%d\n", array[i]);
    }


    // fclose(file);

    fclose(outputFileStream);

}
