To run the base version

gcc -o baseConvolve baseConvolve.c -lm

./baseConvolve 'Big Hall IR/BIG HALL E001 M2S.wav' 'Guitar/GuitarDry.wav' baseConvolve.wav

Profiling base version

gcc -c baseConvolve.c; gcc -o baseConvolve -p baseConvolve.o -lm; ./baseConvolve 'Big Hall IR/BIG HALL E001 M2S.wav' 'Guitar/GuitarDry.wav' baseConvolve.wav; gprof baseConvolve gmon.out

To run the convolveFFT

gcc -o convolveFFT convolveFFT.c -lm

./convolveFFT 'Big Hall IR/BIG HALL E001 M2S.wav' 'Guitar/GuitarDry.wav' convolveFFT.wav

To run the optimizedfft version

gcc -o optfft OptimizedconvolveFFT.c -lm

./optfft 'Big Hall IR/BIG HALL E001 M2S.wav' 'Guitar/GuitarDry.wav' optfft.wav


Profiling optimizedfft

gcc -c OptimizedconvolveFFT.c; gcc -O3 -o OptimizedconvolveFFT -p OptimizedconvolveFFT.o -lm; ./OptimizedconvolveFFT 'Big Hall IR/BIG HALL E001 M2S.wav' 'Guitar/GuitarDry.wav' Optimizedconvolve.wav; gprof OptimizedconvolveFFT gmon.out

