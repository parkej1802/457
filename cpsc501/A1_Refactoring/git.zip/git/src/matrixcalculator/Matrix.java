package matrixcalculator;

/**
 *
 * @author son75
 */
public class Matrix {
    
	MatrixHandleInput handleInput;
	
	public Matrix() {
	    this.handleInput = new MatrixHandleInput();
	}
	
	private MatrixPrint handlePrint = new MatrixPrint();
	
    private int[][] matrix1;
    private int[][] matrix2;
    
    int row1,row2,col1,col2;
            
    
    public int[][] getMatrix1() {
        return matrix1;
    }

    public void setMatrix1(int[][] matrix1) {
        this.matrix1 = matrix1;
    }


    public int[][] getMatrix2() {
        return matrix2;
    }

    public void setMatrix2(int[][] matrix2) {
        this.matrix2 = matrix2;
    }
    
    public int getRow1() {
        return row1;
    }

    public void setRow1(int row1) {
        this.row1 = row1;
    }

    public int getRow2() {
        return row2;
    }

    public void setRow2(int row2) {
        this.row2 = row2;
    }

    public int getCol1() {
        return col1;
    }

    public void setCol1(int col1) {
        this.col1 = col1;
    }

    public int getCol2() {
        return col2;
    }

    public void setCol2(int col2) {
        this.col2 = col2;
    }
        
    public enum MatrixOperation {
        ADDITION,
        SUBTRACTION,
        MULTIPLICATION,
        EXIT
    }
     
    //Multiplication of Matrix
    private void multiplyMatrix(int[][] matrix1, int[][] matrix2){
    	int[][] resultMatrix = MatrixOperatorCalculation.multiply(getMatrix1(), getMatrix2(), getRow1(), getCol1(), getRow2(), getCol2());
    	handlePrint.printMatrix(getMatrix1(), getRow1(), getCol1(), getMatrix2(), getRow2(), getCol2(), resultMatrix, getRow1(), getCol2(), "*");
    }
    //Addition of Matrix
    private void addMatrix(int[][] matrix1,int[][] matrix2, int resultRow,int resultCol){
    	int[][] resultMatrix = MatrixOperatorCalculation.add(getMatrix1(), getMatrix2(), getRow1(), getCol1());
    	handlePrint.printMatrix(getMatrix1(), getRow1(), getCol1(), getMatrix2(), getRow2(), getCol2(), resultMatrix, resultRow, resultCol, "+");
    }
    
    //Subtraction of Matrix
    private void subtractMatrix(int[][] matrix1,int[][] matrix2, int resultRow,int resultCol){
    	int[][] resultMatrix = MatrixOperatorCalculation.subtract(getMatrix1(), getMatrix2(), getRow1(), getCol1());
    	handlePrint.printMatrix(getMatrix1(), getRow1(), getCol1(), getMatrix2(), getRow2(), getCol2(), resultMatrix, resultRow, resultCol, "-");
    }
    
    
    private int getMatrixDimension(String message) {
        System.out.print(message);
        return handleInput.checkArrayElements();
    }
    
    private void performMatrixForMulltiplication(){
        System.out.println("---------Multiplication-----------");
        setRow1(getMatrixDimension("Enter row matrix 1: "));
        setCol1(getMatrixDimension("Enter column matrix 1: "));
        setMatrix1(handleInput.initializeMatrix(getRow1(), getCol1())); //Extract Method
        setRow2(handleInput.validateMatrixRowsForMultiplication(getCol1())); //Extract Method
        System.out.print("Enter column matrix 2:");
        setCol2(handleInput.checkArrayElements());
        setMatrix2(handleInput.initializeMatrix(getRow2(), getCol2())); //Extract Method
        multiplyMatrix(getMatrix1(), getMatrix2());
    }
    
    private void performMatrixForAddition(){
        System.out.println("-------------Addition------------");
        setRow1(getMatrixDimension("Enter row matrix 1: "));
        setCol1(getMatrixDimension("Enter column matrix 1: "));
        setMatrix1(handleInput.initializeMatrix(getRow1(), getCol1())); //Extract Method
        handleInput.validateMatrixForAddOrSub(getRow1(), getCol1());
        setMatrix2(handleInput.initializeMatrix(getRow2(), getCol2())); //Extract Method
        addMatrix(getMatrix1(), getMatrix2(), getRow1(), getCol1());
    }
    
    private void performMatrixForSubtraction(){
        System.out.println("-------------Subtraction------------");
        setRow1(getMatrixDimension("Enter row matrix 1: "));
        setCol1(getMatrixDimension("Enter column matrix 1: "));
        setMatrix1(handleInput.initializeMatrix(getRow1(), getCol1())); //Extract Method
        handleInput.validateMatrixForAddOrSub(getRow1(), getCol1());
        setMatrix2(handleInput.initializeMatrix(getRow2(), getCol2())); //Extract Method
        subtractMatrix(getMatrix1(), getMatrix2(), getRow1(), getCol1());
    }
    
    public void getOperation(MatrixOperation operation){
        switch(operation){
            case ADDITION:
                performMatrixForAddition();
                break;
            case SUBTRACTION:
                performMatrixForSubtraction();
                break;
            case MULTIPLICATION:
                performMatrixForMulltiplication();
                break;
            default:
                System.out.println("Invalid command! Please enter again: ");
        }
    }
}

