package matrixcalculator;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MatrixEncapsulationTest {

	private Matrix matrix;
	
	@Before
    public void setUp() {
        matrix = new Matrix();
    }
	
	@Test
    public void testSetGetMatrix1() {
        int[][] TestMatrix = {
            {14, 25},
            {63, 64}
        };
        matrix.setMatrix1(TestMatrix);
        assertArrayEquals(TestMatrix, matrix.getMatrix1());
    }
	
    @Test
    public void testSetGetMatrix2() {
        int[][] TestMatrix = {
            {52, 16},
            {72, 85}
        };
        matrix.setMatrix2(TestMatrix);
        assertArrayEquals(TestMatrix, matrix.getMatrix2());
    }
    
    @Test
    public void testSetGetRow1() {
        int TestValue = 576;
        matrix.setRow1(TestValue);
        assertEquals(TestValue, matrix.getRow1());
    }

    @Test
    public void testSetGetRow2() {
        int TestValue = 635;
        matrix.setRow2(TestValue);
        assertEquals(TestValue, matrix.getRow2());
    }

    @Test
    public void testSetGetCol1() {
        int TestValue = 157;
        matrix.setCol1(TestValue);
        assertEquals(TestValue, matrix.getCol1());
    }

    @Test
    public void testSetGetCol2() {
        int TestValue = 827;
        matrix.setCol2(TestValue);
        assertEquals(TestValue, matrix.getCol2());
    }
}