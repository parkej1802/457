package matrixcalculator;

import java.util.Scanner;

public class MatrixHandleInput {
	
    private final Scanner sc = new Scanner(System.in);
	
	public int[][] initializeMatrix(int rowCount, int colCount) {
        int[][] matrix = new int[rowCount][colCount];
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                System.out.print("Enter Matrix [" + (i + 1) + "][" + (j + 1) + "]: ");
                matrix[i][j] = checkInputInt();
            }
        }
        return matrix;
    }
	
	//Integer validator
    public int checkInputInt(){
        while(true){
            try {
                int result = Integer.parseInt(sc.nextLine().trim());
                return result;
            } catch (NumberFormatException e) {
                System.out.println("Integer number not found");
            }
        }
    }
  //Matrix row and col >0
    public int checkArrayElements(){
        while(true){
            try {
                int result = Integer.parseInt(sc.nextLine().trim());
                if (isPositive(result)==true) return result;
                else System.out.println("The number of row/column must be higher than 0, please enter again: ");
            } catch (NumberFormatException e) {
                System.out.println("Integer not found, please enter again: ");
            }
        }
    }
    
    private boolean isPositive(int result){
    	return result > 0;
    }
    
    public int validateMatrixRowsForMultiplication(int col1) {
        while(true){
            System.out.print("Enter row matrix 2:");
            int row2 = checkArrayElements();
            if (row2 == col1) return row2;
            System.out.println("Invalid Matrix for multiplication, column of matrix 1 must equal row of matrix 2.");
        } 
    }
    
    public void validateMatrixForAddOrSub(int expectedRows, int expectedCols) {
    	int row2, col2;
        while (true) {
            System.out.print("Enter row matrix 2:");
            row2 = checkArrayElements();
            if (row2 == expectedRows) break;
            System.out.println("Invalid Matrix, both matrices must have the same number of rows.");
        }
        
        while (true) {
            System.out.print("Enter column matrix 2:");
            col2 = checkArrayElements();
            if (col2 == expectedCols) break;
            System.out.println("Invalid Matrix, both matrices must have the same number of columns.");
        }
    }

}
