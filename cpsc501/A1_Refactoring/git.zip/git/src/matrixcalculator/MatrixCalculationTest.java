package matrixcalculator;

import org.junit.Test;
import static org.junit.Assert.*;

public class MatrixCalculationTest {
    

    @Test
    public void testAddMatrix() {
        int[][] matrix1 = {
            {1, 2},
            {3, 4}
        };

        int[][] matrix2 = {
            {2, 3},
            {4, 5}
        };

        int[][] expected = {
            {3, 5},
            {7, 9}
        };

        int[][] result = MatrixOperatorCalculation.add(matrix1, matrix2, 2, 2);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testSubtractMatrix() {
        int[][] matrix1 = {
            {5, 6},
            {7, 8}
        };

        int[][] matrix2 = {
            {2, 3},
            {4, 5}
        };

        int[][] expected = {
            {3, 3},
            {3, 3}
        };

        int[][] result = MatrixOperatorCalculation.subtract(matrix1, matrix2, 2, 2);
        assertArrayEquals(expected, result);
    }

    @Test
    public void testMultiplyMatrix() {
        int[][] matrix1 = {
            {1, 2},
            {3, 4}
        };

        int[][] matrix2 = {
            {2, 0},
            {1, 3}
        };

        int[][] expected = {
            {4, 6},
            {10, 12}
        };

        int[][] result = MatrixOperatorCalculation.multiply(matrix1, matrix2, 2, 2, 2, 2);
        assertArrayEquals(expected, result);
    }
}