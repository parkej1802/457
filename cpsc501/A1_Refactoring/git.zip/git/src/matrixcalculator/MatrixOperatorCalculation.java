package matrixcalculator;

public class MatrixOperatorCalculation {
	
	public static int[][] multiply(int[][] matrix1, int[][] matrix2, int row1, int col1, int row2, int col2) {
        int[][] result = new int[row1][col2];
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col2; j++) {
                for (int k = 0; k < row2; k++) {
                    result[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }
        return result;
    }
	
	public static int[][] add(int[][] matrix1, int[][] matrix2, int row, int col) {
		int[][] result = new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                result[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }
        return result;
	}
	
	public static int[][] subtract(int[][] matrix1, int[][] matrix2, int row, int col) {
        int[][] result = new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                result[i][j] = matrix1[i][j] - matrix2[i][j];
            }
        }
        return result;
    }
}
	
	
	

