package matrixcalculator;

import matrixcalculator.Matrix.MatrixOperation;

/**
 *
 * @author son75
 */

public class MatrixCalculator {
	
	public void printChoice() {
		System.out.println("===========Calculator Program=============");
        System.out.println("1. Addition Matrix.");
        System.out.println("2. Subtraction Matrix.");
        System.out.println("3. Multiplication Matrix.");
        System.out.println("4. Exit.");
	}

	public void menu(){
	    MatrixOperation choice = null;
	    Matrix mat = new Matrix();
	    do {
	        printChoice();   
	        int input = mat.handleInput.checkInputInt();
	        
	        switch(input) {
	            case 1:
	                choice = MatrixOperation.ADDITION;
	                break;
	            case 2:
	                choice = MatrixOperation.SUBTRACTION;
	                break;
	            case 3:
	                choice = MatrixOperation.MULTIPLICATION;
	                break;
	            case 4:
	                choice = MatrixOperation.EXIT;
	                break;
	            default:
	                System.out.println("Invalid command! Please enter again: ");
	                continue;
	        }

	        mat.getOperation(choice);
	        
	    } while (choice != MatrixOperation.EXIT);
	}

    public static void main(String[] args) {
        // TODO code application logic here
        MatrixCalculator mc = new MatrixCalculator();
        mc.menu();
    }
    
}