package matrixcalculator;

public class MatrixPrint {
	public void printSingleMatrix(int[][] matrix, int rows, int cols) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print("[" + matrix[i][j] + "] ");
            }
            System.out.println();
        }
    }
    
	public void printMatrixHeader(String header) {
        System.out.println(header);
    }

    public void printOperation(String op) {
        System.out.println(op);
    }
    
    public void printMatrix(int[][] matrix1, int rows1, int cols1, 
            				int[][] matrix2, int rows2, int cols2, 
            				int[][] resultMatrix, int resultRows, int resultCols, String op) {
        printMatrixHeader("----------------Result-----------------");
        printSingleMatrix(matrix1, rows1, cols1);
        printOperation(op);
        printSingleMatrix(matrix2, rows2, cols2);
        System.out.println("=");
        printSingleMatrix(resultMatrix, resultRows, resultCols);
    }
}
