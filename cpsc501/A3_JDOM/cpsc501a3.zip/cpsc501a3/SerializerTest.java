package cpsc501a3;

import org.jdom2.Document;
import org.jdom2.Element;
import org.junit.Test;

import static org.junit.Assert.*;

import java.util.List;

public class SerializerTest {
    @Test
    public void testSerialize() {
        Serializer serializer = new Serializer();
        PrimitiveObject primitiveObject = new PrimitiveObject();
        Document document = serializer.serialize(primitiveObject, "test.xml");

        assertNotNull(document);
        Element rootElement = document.getRootElement();
        assertEquals("serialized", rootElement.getName());

        Element objectElement = rootElement.getChild("object");
        assertNotNull(objectElement);
        assertEquals("cpsc501a3.PrimitiveObject", objectElement.getAttributeValue("class"));
        assertEquals("0", objectElement.getAttributeValue("id"));

        Element fieldElement = objectElement.getChild("field");
        assertNotNull(fieldElement);
        assertEquals("intValue", fieldElement.getAttributeValue("name"));
        assertEquals("cpsc501a3.PrimitiveObject", fieldElement.getAttributeValue("declaringclass"));

        Element valueElement = fieldElement.getChild("value");
        assertNotNull(valueElement);
        assertEquals("0", valueElement.getText());
    }
    
    @Test
    public void testSerializeArray() {
        Serializer serializer = new Serializer();
        int[] array = {23, 11, 3, -11, 9};
        Document document = serializer.serialize(array, "test.xml");

        assertNotNull(document);
        Element rootElement = document.getRootElement();
        assertEquals("serialized", rootElement.getName());

        Element objectElement = rootElement.getChild("object");
        assertNotNull(objectElement);
        assertEquals("[I", objectElement.getAttributeValue("class"));
        assertEquals("1", objectElement.getAttributeValue("id"));
        assertEquals("5", objectElement.getAttributeValue("length"));
        
        List<Element> valueElements = objectElement.getChildren("value");
        assertEquals(5, valueElements.size());
        for (int i = 0; i < valueElements.size(); i++) {
            Element valueElement = valueElements.get(i);
            assertEquals(String.valueOf(array[i]), valueElement.getText());
        }
    }
}
