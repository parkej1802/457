package cpsc501a3;
import java.lang.reflect.*;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Scanner;

public class objectCreator {

    public static void main(String[] args) {
        objectCreator menuSystem = new objectCreator();
        menuSystem.runMenu();
    }

    private void runMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("------------- Menu -------------");
            System.out.println("1. Create Primitives Object");
            System.out.println("2. Create Reference Object");
            System.out.println("3. Create Primitive Array Object");
            System.out.println("4. Create Reference Array Object");
            System.out.println("5. Create Collection Object");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            
            while (!scanner.hasNextInt()) {
                scanner.next();
                System.out.println("Please enter a number between 1 and 6.");
                System.out.print("Choose an option: ");
            }

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    createPrimitiveObject();
                    break;
                case 2:
                    createReferenceObject();
                    break;
                case 3:
                    createPrimitiveArrayObject();
                    break;
                case 4:
                    createReferenceArrayObject();
                    break;
                case 5:
                    createCollectionObject();
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    System.out.println("Please select between 1 to 6.");
            }
        }

        scanner.close();
    }

    	
    public void changeValuePrint() {
        System.out.println("Would you like to change the values? yes or no");
    }
    
    public void wrongInputPrint() {
    	System.out.println("Wrong input. Please enter yes or no.");
    }
    
    public void serializeObjectPrint() {
    	System.out.println("Would you like to serialize the object? yes or no");
    }
    
    public void wrongInputIntPrint() {
    	System.out.println("Wrong input. Please enter integer value");
    }
    
    private boolean YesorNoResponse(String response) {
        return response.equalsIgnoreCase("yes") || response.equalsIgnoreCase("no");
    }
    
    private PrimitiveObject createPrimitiveObject() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Create Primitive Object");

        PrimitiveObject primitiveObject = new PrimitiveObject();

        changeValuePrint();
        String response = scanner.next();
        while (!YesorNoResponse(response)) {
            wrongInputPrint();
            response = scanner.next();
        }
        if (response.equalsIgnoreCase("yes")) {
            System.out.print("Enter an integer value: ");
            while (!scanner.hasNextInt()) {
            	wrongInputIntPrint();
                scanner.next();
            }
            int intValue = scanner.nextInt();

            System.out.print("Enter a double value: ");
            while (!scanner.hasNextDouble()) {
                System.out.println("Wrong Input. Please enter double value.");
                scanner.next();
            }
            double doubleValue = scanner.nextDouble();

            System.out.print("Enter a boolean value: ");
            while (!scanner.hasNextBoolean()) {
                System.out.println("Wrong Input. Please enter boolean value.");
                scanner.next();
            }
            boolean booleanValue = scanner.nextBoolean();

            setPrimitiveObjectValues(primitiveObject, intValue, doubleValue, booleanValue);
        }
        Serializer serializer = new Serializer();
        Send sender = new Send();

        serializeObjectPrint();
        response = scanner.next();
        while (!YesorNoResponse(response)) {
            wrongInputPrint();
            response = scanner.next();
        }
        if (response.equalsIgnoreCase("yes")) {
        	Document document = serializer.serialize(primitiveObject, "primitiveObject.xml");
        	sender.sendDocument(document);
        }

        scanner.nextLine();

        return primitiveObject;
    }

        
    private void createReferenceObject() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Create Reference Object");

        ReferenceObject referenceObject = new ReferenceObject();

        
        PrimitiveObject primitiveObject = createPrimitiveObject();
        setReferenceObjectValues(referenceObject, primitiveObject);
        

        Serializer serializer = new Serializer();
        Send sender = new Send();

        serializeObjectPrint();
        String response = scanner.next();
        while (!YesorNoResponse(response)) {
        	wrongInputPrint();
            response = scanner.next();
        }
        if (response.equalsIgnoreCase("yes")) {
            Document document = serializer.serialize(referenceObject, "referenceObject.xml");
            sender.sendDocument(document);
        }
    }

    
    private PrimitiveArrayObject createPrimitiveArrayObject() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Create Primitive Array Object");
        
        PrimitiveArrayObject primitiveArrayObject = new PrimitiveArrayObject();
        
        changeValuePrint();
        String response = scanner.next();
        while (!YesorNoResponse(response)) {
        	wrongInputPrint();
            response = scanner.next();
        }
        if (response.equalsIgnoreCase("yes")) {

	        System.out.print("Enter the size of the array: ");
	        while (!scanner.hasNextInt()) {
	        	wrongInputIntPrint();
	            scanner.next();
	        }
	        int size = scanner.nextInt();
	
	        int[] primitiveArray = new int[size];
	
	        for (int i = 0; i < size; i++) {
	            System.out.println("Enter value for element " + (i+1));
	            while (!scanner.hasNextInt()) {
	            	wrongInputIntPrint();
	                scanner.next();
	            }
	            primitiveArray[i] = scanner.nextInt();
	        }
	        setPrimitiveArrayObjectValues(primitiveArrayObject, primitiveArray);
        }
        
        Serializer serializer = new Serializer();
        Send sender = new Send();

        serializeObjectPrint();
        response = scanner.next();
        while (!YesorNoResponse(response)) {
        	wrongInputPrint();
            response = scanner.next();
        }
        if (response.equalsIgnoreCase("yes")) {
        	Document document = serializer.serialize(primitiveArrayObject, "primitiveArrayObject.xml");
        	sender.sendDocument(document);
        }
		return primitiveArrayObject;
    }



    private void createReferenceArrayObject() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Create Reference Array Object");

        ReferenceArrayObject referenceArrayObject = new ReferenceArrayObject();


        PrimitiveArrayObject primitiveArrayObject = createPrimitiveArrayObject();
        setReferenceArrayObjectValues(referenceArrayObject, primitiveArrayObject);
        

        Serializer serializer = new Serializer();
        Send sender = new Send();

        serializeObjectPrint();
        String response = scanner.next();
        while (!YesorNoResponse(response)) {
        	wrongInputPrint();
            response = scanner.next();
        }
        if (response.equalsIgnoreCase("yes")) {
            Document document = serializer.serialize(referenceArrayObject, "referenceArrayObject.xml");
            sender.sendDocument(document);
        }
    }



    private void createCollectionObject() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Create Collection Object");

        CollectionObject collectionObject = new CollectionObject();
        ArrayList<PrimitiveObject> list = new ArrayList<>();

        System.out.println("How many PrimitiveObjects would you like to create? Enter a number:");
        while (!scanner.hasNextInt()) {
            System.out.println("Please enter number:");
            scanner.next();
        }
        
        int numOfObjects = scanner.nextInt();

        for (int i = 0; i < numOfObjects; i++) {
            System.out.println("Creating PrimitiveObject " + (i+1));
            PrimitiveObject primitiveObject = createPrimitiveObject();
            list.add(primitiveObject);
        }

        setCollectionObjectValues(collectionObject, list);

        Serializer serializer = new Serializer();
        Send sender = new Send();
        
        serializeObjectPrint();
        String response = scanner.next();
        while (!YesorNoResponse(response)) {
        	wrongInputPrint();
            response = scanner.next();
        }
        if (response.equalsIgnoreCase("yes")) {
            Document document = serializer.serialize(collectionObject, "collectionObject.xml");
            sender.sendDocument(document);
        }
    }


    public void setPrimitiveObjectValues(PrimitiveObject primitiveObject, int intValue, double doubleValue, boolean booleanValue) {
        try {
            Field field = PrimitiveObject.class.getDeclaredField("intValue");
            field.setAccessible(true);
            field.setInt(primitiveObject, intValue);

            field = PrimitiveObject.class.getDeclaredField("doubleValue");
            field.setAccessible(true);
            field.setDouble(primitiveObject, doubleValue);

            field = PrimitiveObject.class.getDeclaredField("booleanValue");
            field.setAccessible(true);
            field.setBoolean(primitiveObject, booleanValue);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        
    }
    
    public void setPrimitiveArrayObjectValues(PrimitiveArrayObject primitiveArrayObject, int[] array) {
        try {
            Field field = PrimitiveArrayObject.class.getDeclaredField("array");
            field.setAccessible(true);
            field.set(primitiveArrayObject, array);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    
    public void setReferenceObjectValues(ReferenceObject referenceObject, PrimitiveObject primitiveObject) {
        try {
            Field field = ReferenceObject.class.getDeclaredField("primitiveObject");
            field.setAccessible(true);
            field.set(referenceObject, primitiveObject);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    
    public void setReferenceArrayObjectValues(ReferenceArrayObject referenceArrayObject, PrimitiveArrayObject primitiveArrayObject) {
        try {
            Field field = ReferenceArrayObject.class.getDeclaredField("primitiveArrayObject");
            field.setAccessible(true);
            field.set(referenceArrayObject, primitiveArrayObject);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    
    public void setCollectionObjectValues(CollectionObject collectionObject, ArrayList<PrimitiveObject> list) {
        try {
            Field field = CollectionObject.class.getDeclaredField("collectionObject");
            field.setAccessible(true);
            field.set(collectionObject, list);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    
}
