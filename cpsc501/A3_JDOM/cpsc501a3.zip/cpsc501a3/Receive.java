package cpsc501a3;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import org.jdom2.Document;
import org.jdom2.input.SAXBuilder;

public class Receive {
    public static void main(String[] args) {
        try {
            System.out.println("Waiting for Connection");
            ServerSocket serverSocket = new ServerSocket(12345);

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Connected");
                
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);

                SAXBuilder saxBuilder = new SAXBuilder();
                Document doc = saxBuilder.build(isr);

                Deserializer deserializer = new Deserializer();
                Object object = deserializer.deserialize(doc);
                
                Inspector inspector = new Inspector();
                inspector.inspect(object, true);

                isr.close();
                is.close();
                socket.close();
                
                System.out.println("Next");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
