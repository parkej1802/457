package cpsc501a3;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import org.jdom2.Document;
import org.jdom2.output.XMLOutputter;

public class Send {
    public void sendDocument(Document document) {
        try {
            Socket socket = new Socket("localhost", 12345);
            OutputStream os = socket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(os);

            XMLOutputter xmlOutputter = new XMLOutputter();
            xmlOutputter.output(document, osw);

            osw.flush();

            osw.close();
            os.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
