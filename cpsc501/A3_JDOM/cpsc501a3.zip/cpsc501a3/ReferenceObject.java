package cpsc501a3;

public class ReferenceObject {
    PrimitiveObject primitiveObject;

    public ReferenceObject() {
        
    }
}