package cpsc501a3;

import java.util.ArrayList;

public class CollectionObject {
    private ArrayList<PrimitiveObject> collectionObject;

    public CollectionObject() {

    }
}