package cpsc501a3;
import org.jdom2.*;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import java.io.FileWriter;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.IdentityHashMap;

public class Serializer {
    private IdentityHashMap<Object, Integer> objectID = new IdentityHashMap<>();
    private static int id = 0;

    public Document serialize(Object object, String filename) {
        Document document = new Document(new Element("serialized"));
        serializeObject(object, document.getRootElement());
        
        XMLOutputter xmlOutputter = new XMLOutputter(Format.getPrettyFormat());
        String xmlString = xmlOutputter.outputString(document);
        System.out.println(xmlString);

        try (FileWriter fileWriter = new FileWriter(filename)) {
            xmlOutputter.output(document, fileWriter);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return document;
    }

    private void serializeObject(Object object, Element parent) {
        Class<?> classObject = object.getClass();
        String className = classObject.getName(); 
        int currentId;

        if (objectID.containsKey(object)) {
            currentId = objectID.get(object);
            Element reference = new Element("reference");
            reference.setText(String.valueOf(currentId));
            parent.addContent(reference);
        } else {
            currentId = id++;
            objectID.put(object, currentId);
            
            Element objectElement = new Element("object");
            objectElement.setAttribute("class", className);
            objectElement.setAttribute("id", String.valueOf(currentId));
            parent.addContent(objectElement);

            if (classObject.isArray()) {
                serializeArray(object, objectElement);
            } else {
                serializeFields(object, classObject, objectElement);
            }
        }
    }

    private void serializeArray(Object array, Element parent) {
        int length = Array.getLength(array);
        parent.setAttribute("length", Integer.toString(length));

        Class<?> componentType = array.getClass().getComponentType();
        for (int i = 0; i < length; i++) {
            if (componentType.isPrimitive()) {
                String value;
                if (componentType.equals(int.class)) {
                    value = Integer.toString(Array.getInt(array, i));
                } 
                else {
                    throw new IllegalArgumentException("Not a Primitive Type");
                }
                parent.addContent(new Element("value").setText(value));
            } else {
                serializeObject(Array.get(array, i), parent);
            }
        }
    }


    private void serializeFields(Object object, Class<?> classObject, Element parent) {
        Field[] fields = classObject.getDeclaredFields();
        for (Field field : fields) {
            Element fieldElement = new Element("field");
            fieldElement.setAttribute("name", field.getName());
            fieldElement.setAttribute("declaringclass", classObject.getName());
            parent.addContent(fieldElement);

            field.setAccessible(true);
            try {
                if (field.getType().isPrimitive()){
                    String fieldValue;
                    Class<?> fieldType = field.getType();
                    if (fieldType.equals(int.class)) {
                        fieldValue = Integer.toString(field.getInt(object));
                    } else if (fieldType.equals(boolean.class)) {
                        fieldValue = Boolean.toString(field.getBoolean(object));
                    } else if (fieldType.equals(double.class)) {
                        fieldValue = Double.toString(field.getDouble(object));
                    } else {
                        throw new IllegalArgumentException("Not a Primitive Type");
                    }
                    fieldElement.addContent(new Element("value").setText(fieldValue));
                } else {
                    Object fieldValue = field.get(object);
                    if (fieldValue != null) {
                        if (field.getType().isArray()) {
                            serializeArray(fieldValue, fieldElement);
                        }
                        else if (fieldValue instanceof ReferenceObject) {
                            Object primitiveObject = ((ReferenceObject) fieldValue).primitiveObject;
                            if (!objectID.containsKey(primitiveObject)) {
                                objectID.put(primitiveObject, id++);
                            }
                            Element reference = new Element("reference");
                            reference.setText(String.valueOf(objectID.get(primitiveObject)));
                            fieldElement.addContent(reference);
                        } else {
                            if (!objectID.containsKey(fieldValue)) {
                                objectID.put(fieldValue, id++);
                            }
                            serializeObject(fieldValue, fieldElement);
                        }
                    }
                    else {
                    	Element valueElement = new Element("value");
                    	valueElement.setText("null");
                    	fieldElement.addContent(valueElement);
                    }
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }

}
