package cpsc501a3;

public class PrimitiveObject {
    private int intValue;
    private double doubleValue;
    private boolean booleanValue;

    public PrimitiveObject() {

    }
}