package cpsc501a3;

public class PrimitiveArrayObject {
    private int[] array;
    
    public PrimitiveArrayObject() {
    	
    }
}
