package cpsc501a3;

import org.jdom2.Document;
import org.jdom2.Element;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Deserializer {
    private Map<Integer, Object> objectID = new HashMap<>();

    public Object deserialize(Document document) throws Exception {
        Element rootElement = document.getRootElement();
        List<Element> childElements = rootElement.getChildren();
        for (Element childElement : childElements) {
            int id = Integer.parseInt(childElement.getAttributeValue("id"));
            String className = childElement.getAttributeValue("class");
            Class<?> classObject = Class.forName(className);

            Object object;
            if (classObject.isArray()) {
                int length = Integer.parseInt(childElement.getAttributeValue("length"));
                object = Array.newInstance(classObject.getComponentType(), length);
            } else {
                object = classObject.getDeclaredConstructor().newInstance();
            }
            
            objectID.put(id, object);

            List<Element> fieldElements = childElement.getChildren();
            for (Element fieldElement : fieldElements) {
                String fieldName = fieldElement.getAttributeValue("name");
                String declaringClassName = fieldElement.getAttributeValue("declaringclass");
                Class<?> declaringClass = Class.forName(declaringClassName);
                Field field = declaringClass.getDeclaredField(fieldName);
                field.setAccessible(true);

                if (field.getType().isArray()) {
                    String lengthStr = fieldElement.getAttributeValue("length");
                    int length = (lengthStr == null || lengthStr.isEmpty()) ? 0 : Integer.parseInt(lengthStr);
                    Object array = Array.newInstance(field.getType().getComponentType(), length);
                    field.set(object, array);
                    for (int i = 0; i < length; i++) {
                        Element itemElement = fieldElement.getChildren().get(i);
                        if (itemElement.getName().equals("value")) {
                            String valueStr = itemElement.getText();
                            Array.set(array, i, Integer.parseInt(valueStr));
                        } else if (itemElement.getName().equals("reference")) {
                            int referenceId = Integer.parseInt(itemElement.getText());
                            Object referenceObject = objectID.get(referenceId);
                            Array.set(array, i, referenceObject);
                        }
                    }
                } else {
                	if (fieldElement.getChild("value") != null) {
                	    Element valueElement = fieldElement.getChild("value");
                	    if (field.getType().equals(int.class)) {
                	        field.setInt(object, Integer.parseInt(valueElement.getText()));
                	    } else if (field.getType().equals(double.class)) {
                	        field.setDouble(object, Double.parseDouble(valueElement.getText()));
                	    } else if (field.getType().equals(boolean.class)) {
                	        field.setBoolean(object, Boolean.parseBoolean(valueElement.getText()));
                	    } else {
                	        int objectId = Integer.parseInt(valueElement.getText());
                	        Object valueObject = objectID.get(objectId);
                	        field.set(object, valueObject);
                	    }
                	} else {
                	    Element referenceElement = fieldElement.getChild("reference");
                	    if (referenceElement != null) {
                	        int referenceId = Integer.parseInt(referenceElement.getText());
                	        Object referenceObject = objectID.get(referenceId);
                	        field.set(object, referenceObject);
                	    } else {
                	        field.set(object, null);
                	    }
                	}

                }
            }
        }

        int rootId = Integer.parseInt(childElements.get(0).getAttributeValue("id"));
        return objectID.get(rootId);
    }
}
