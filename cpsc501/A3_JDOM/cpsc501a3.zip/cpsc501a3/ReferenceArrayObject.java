package cpsc501a3;

public class ReferenceArrayObject {
    PrimitiveArrayObject primitiveArrayObject;

    public ReferenceArrayObject() {
        
    }
}