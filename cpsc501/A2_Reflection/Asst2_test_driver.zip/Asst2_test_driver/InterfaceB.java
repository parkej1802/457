
public interface InterfaceB
{

    public void func0(int a,boolean c) throws Exception;

}
